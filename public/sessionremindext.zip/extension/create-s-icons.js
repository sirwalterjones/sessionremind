// Create simple S logo PNG icons using Canvas API in Node.js
const fs = require('fs');
const { createCanvas } = require('canvas');

function createSIcon(size) {
  const canvas = createCanvas(size, size);
  const ctx = canvas.getContext('2d');
  
  // Black background
  ctx.fillStyle = '#000000';
  ctx.fillRect(0, 0, size, size);
  
  // White S text
  ctx.fillStyle = '#ffffff';
  ctx.font = `bold ${Math.floor(size * 0.6)}px Arial`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('S', size / 2, size / 2);
  
  return canvas.toBuffer('image/png');
}

// Create icons
fs.writeFileSync('icons/icon16.png', createSIcon(16));
fs.writeFileSync('icons/icon48.png', createSIcon(48));
fs.writeFileSync('icons/icon128.png', createSIcon(128));

console.log('S logo icons created successfully!');